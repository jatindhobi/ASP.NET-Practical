﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Repeatercontrol
{
    public partial class repeater : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Simulate data retrieval from a data source (e.g., a database)
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("Name", typeof(string));
                dataTable.Columns.Add("Age", typeof(int));
                dataTable.Rows.Add("John", 30);
                dataTable.Rows.Add("Jane", 25);
                dataTable.Rows.Add("Alice", 28);

                // Bind the data to the Repeater control
                Repeater1.DataSource = dataTable;
                Repeater1.DataBind();
            }
        }

    }
}