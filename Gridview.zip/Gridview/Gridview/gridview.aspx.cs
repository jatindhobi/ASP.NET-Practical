﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Gridview
{
    public partial class gridview : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                // Simulate data retrieval from a data source (e.g., a database)
                DataTable dataTable = new DataTable();
                dataTable.Columns.Add("ID", typeof(int));
                dataTable.Columns.Add("Name", typeof(string));
                dataTable.Rows.Add(1, "John");
                dataTable.Rows.Add(2, "Jane");
                dataTable.Rows.Add(3, "Alice");

                // Bind the data to the GridView control
                GridView1.DataSource = dataTable;
                GridView1.DataBind();
            }
        }
    }
}