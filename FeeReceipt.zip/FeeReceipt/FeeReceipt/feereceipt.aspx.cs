﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace FeeReceipt
{
    public partial class feereceipt : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnGenerateReceipt_Click(object sender, EventArgs e)
        {
            string name = txtName.Text;
            string examType = txtExamType.Text;
            string year = txtYear.Text;
            string semester = txtSemester.Text;
            string subjects = txtSubjects.Text;
            decimal fees = decimal.Parse(txtFees.Text);

            // Create the fee receipt
            string receipt = $@"<h2>Fee Receipt</h2>
                                <p><strong>Name:</strong> {name}</p>
                                <p><strong>Exam Type:</strong> {examType}</p>
                                <p><strong>Year:</strong> {year}</p>
                                <p><strong>Semester:</strong> {semester}</p>
                                <p><strong>Subjects:</strong> {subjects}</p>
                                <p><strong>Fees:</strong> ${fees:0.00}</p>";

            // Display the fee receipt on the page
            lblReceipt.Text = receipt;
        }
    }
}