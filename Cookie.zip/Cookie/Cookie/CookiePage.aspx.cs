﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Cookie
{
    public partial class CookiePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("Cookie Program");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Cookies["name"].Value = TextBox1.Text.ToString();
            Response.Cookies["age"].Value = TextBox2.Text.ToString();
            Label1.Text = ("Cookie Creatted");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            string name = Request.Cookies["name"].Value;
            Label2.Text = name;

            string age = Request.Cookies["age"].Value;
            Label3.Text = age;
        }
    }
}