﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Birthdate_Check
{
    public partial class birthdate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnCheck_Click(object sender, EventArgs e)
        {
            DateTime bdate;
            if (!DateTime.TryParse(txtBdate.Text, out bdate))
            {
                lblResult.Text = "Bdate is not a valid date.";
                return;
            }

            // Step 2: Check that "Bdate" is greater than the current date
            if (bdate > DateTime.Now)
            {
                lblResult.Text = "Bdate not greater than today.";
                return;
            }

            // Step 3: Check that "End Date" is greater than "Start Date"
            DateTime startDate, endDate;
            if (!DateTime.TryParse(txtStartDate.Text, out startDate) || !DateTime.TryParse(txtEndDate.Text, out endDate))
            {
                lblResult.Text = "Start Date or End Date is not a valid date.";
                return;
            }

            if (endDate <= startDate)
            {
                lblResult.Text = "End Date must be greater than Start Date.";
                return;
            }

            lblResult.Text = "All date checks passed.";
        }
    }
}