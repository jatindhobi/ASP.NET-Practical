﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Marksheet
{
    public partial class Marksheet : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("Marksheet Program");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            int marks1,marks2,marks3,marks4,marks5,total;
            double percentage;

            marks1=int.Parse(TextBox2.Text);
            marks2 =int.Parse(TextBox3.Text);
            marks3 =int.Parse(TextBox4.Text);
            marks4 =int.Parse(TextBox5.Text);
            marks5 =int.Parse(TextBox6.Text);

            total=marks1 + marks2 + marks3 + marks4 + marks5;
            TextBox7.Text= total.ToString();

            percentage = (total * 100) / 500;
            TextBox8.Text= percentage.ToString();

            if (percentage >= 33)
            {
                TextBox9.Text="Pass";
            }
            else
            {
                TextBox9.Text = "Fail";
            }
          
        }
    }
}