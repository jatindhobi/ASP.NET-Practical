﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Calculate_Payment
{
    public partial class payment : System.Web.UI.Page
    {
        private double itemCost = 10.0;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DisplayPayment();
            }
        }

        protected void btnIncrement_Click(object sender, EventArgs e)
        {
            int quantity = int.Parse(txtQuantity.Text);
            quantity++;
            txtQuantity.Text = quantity.ToString();
            DisplayPayment();
        }
        protected void btnDecrement_Click(object sender, EventArgs e)
        {
            int quantity = int.Parse(txtQuantity.Text);
            if (quantity > 1)
            {
                quantity--;
                txtQuantity.Text = quantity.ToString();
                DisplayPayment();
            }
        }

        public void DisplayPayment()
        {
            int quantity = int.Parse(txtQuantity.Text);
            double payment = quantity * itemCost;
            lblPayment.Text = $"Payment: {payment:0.00}";
        }

    }
}