﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace DatabaseProgram
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            Response.Write("Database Program </br>");
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            String connectionstring;
            SqlConnection con;

            connectionstring = @"Data Source =(LocalDB)\MSSQLLocalDB;AttachDBFilename=C:\Users\Jatin\source\repos\DatabaseProgram\DatabaseProgram\App_Data\Database1.mdf ; Integrated Security=True";
            con= new SqlConnection(connectionstring);

            con.Open();
            SqlCommand com= new SqlCommand("insert into Student values(@id,@name,@course)", con);
            com.Parameters.AddWithValue("@id", TextBox1.Text);
            com.Parameters.AddWithValue("@name", TextBox2.Text);
            com.Parameters.AddWithValue("@course", TextBox3.Text);

            com.ExecuteNonQuery();
            Label1.Text = ("Record Inserted");
            TextBox1.Text = "";
            TextBox2.Text = ""; 
            TextBox3.Text = "";
            con.Close();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            String connectionstring;
            SqlConnection con;

            connectionstring = @"Data Source =(LocalDB)\MSSQLLocalDB;AttachDBFilename=C:\Users\Jatin\source\repos\DatabaseProgram\DatabaseProgram\App_Data\Database1.mdf ; Integrated Security=True";
            con = new SqlConnection(connectionstring);

            con.Open();
            SqlCommand com = new SqlCommand("UPDATE Student SET Course=@course WHERE id=@id",con);
            com.Parameters.AddWithValue("@id", TextBox4.Text);
            com.Parameters.AddWithValue("@course", TextBox5.Text);
            com.ExecuteNonQuery ();
            Label2.Text = ("Record Updated");
            TextBox4.Text = "";
            TextBox5.Text = "";
            con.Close ();
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            String connectionstring;
            SqlConnection con;

            connectionstring = @"Data Source =(LocalDB)\MSSQLLocalDB;AttachDBFilename=C:\Users\Jatin\source\repos\DatabaseProgram\DatabaseProgram\App_Data\Database1.mdf ; Integrated Security=True";
            con = new SqlConnection(connectionstring);

            con.Open();
            SqlCommand com = new SqlCommand("DELETE FROM Student WHERE id=@id",con);
            com.Parameters.AddWithValue("@id", TextBox6.Text);
            com.ExecuteNonQuery();
            Label3.Text = ("Record Deleted");
            TextBox6.Text = "";
            con .Close();

        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            String connectionstring;
            SqlConnection con;
            SqlDataReader dataReader;

            connectionstring = @"Data Source =(LocalDB)\MSSQLLocalDB;AttachDBFilename=C:\Users\Jatin\source\repos\DatabaseProgram\DatabaseProgram\App_Data\Database1.mdf ; Integrated Security=True";
            con = new SqlConnection(connectionstring);

            con.Open();
            String Output = "";
            SqlCommand com = new SqlCommand("SELECT * FROM Student", con);
            dataReader = com.ExecuteReader();
            while (dataReader.Read())
            {
                Output=Output+dataReader.GetValue(0)+"-"+dataReader.GetValue(1)+"-"+dataReader.GetValue(2)+"</br>";
            }
            Response.Write(Output);
            dataReader.Close();
            con.Close();
        }
    }
}