﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Listbox
{
    public partial class listbox : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void lstSleeveItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            ListItem selectedListItem = lstSleeveItems.SelectedItem;

            // Set the image source and cost label
            lbl.Text = $"{selectedListItem.Value}";
        }
        
    }
}